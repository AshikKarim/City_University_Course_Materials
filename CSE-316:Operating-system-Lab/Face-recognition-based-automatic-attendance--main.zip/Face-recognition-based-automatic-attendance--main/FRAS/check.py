from tkinter import filedialog as fd
filename = fd.askopenfilename()
print(type(filename))